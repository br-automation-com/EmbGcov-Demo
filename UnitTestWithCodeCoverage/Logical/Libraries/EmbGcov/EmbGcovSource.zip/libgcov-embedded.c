

#if ENABLE_LIBGCOV_PORT

#include <stdio.h>
#include <stddef.h>
#include "libgcov-embedded.h"
#include "libgcov.h"
#include <string.h>
#include <AsMem.h>
#include <sys_lib.h>

#include "EmbGcovW.h"

const char* libRemovePath = 0 ;

/* Possible to change the Hook save location */
void EmbGcovSetup(const char* removePath )
{
	libRemovePath = removePath ;
}

/* Function that is called when the GCOV exit is hapening */
void gcov_writeDataHook(unsigned char* bufStart, unsigned char *bufEnd, const char *fileName) {

	uint32_t libRemovePathStrLen = 0;
	
	if( libRemovePath != 0 )
	{
		libRemovePathStrLen = strlen(libRemovePath);
	}

	uint32_t createMemSize = sizeof(EmbGcovWriteTyp) + (bufEnd-bufStart-1) + strlen(fileName) + 1 + libRemovePathStrLen + 1 ;
	uint32_t tmpAllocMem = 0 ;
		
	if( TMP_alloc(createMemSize,(void*)&tmpAllocMem) == 0)
	{
		EmbGcovWriteTyp* EmbGcovWriteInfo = (EmbGcovWriteTyp*) tmpAllocMem ;
			
		EmbGcovWriteInfo->pFileName = tmpAllocMem + sizeof(EmbGcovWriteTyp) ;
		EmbGcovWriteInfo->fileNameSize = strlen(fileName);
		
		EmbGcovWriteInfo->pRemovePath = 0 ;
		if(libRemovePath != 0) EmbGcovWriteInfo->pRemovePath = tmpAllocMem + sizeof(EmbGcovWriteTyp) + strlen(fileName) + 1 ;
		EmbGcovWriteInfo->removePathSize = libRemovePathStrLen;
		
		EmbGcovWriteInfo->pData = tmpAllocMem + sizeof(EmbGcovWriteTyp) + strlen(fileName) + 1  + libRemovePathStrLen + 1;
		EmbGcovWriteInfo->dataSize = (bufEnd-bufStart-1);
		EmbGcovWriteInfo->totalBufferSize = createMemSize;
			
		strcpy((char*) EmbGcovWriteInfo->pFileName , fileName );
		if(libRemovePath != 0) strcpy((char*) EmbGcovWriteInfo->pRemovePath , libRemovePath );
		memcpy((void*) EmbGcovWriteInfo->pData , bufStart , (bufEnd-bufStart-1));
		
		EmbGcovWrite( EmbGcovWriteInfo );
	}
}

	
#endif /* ENABLE_LIBGCOV_PORT */
